-- This file should undo anything in `up.sql`
DROP TABLE statistic_runes;
-- Your SQL goes here
CREATE TABLE statistic_runes (
  id SERIAL PRIMARY KEY,
  rune VARCHAR NOT NULL,
  rune_counter INTEGER NOT NULL DEFAULT 0
)
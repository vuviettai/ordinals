-- Your SQL goes here
CREATE TABLE rune_entries (
  id BIGSERIAL PRIMARY KEY,
  rune_height INTEGER NOT NULL,
  rune_index SMALLINT NOT NULL DEFAULT 0,
  burned BYTEA NOT NULL,
  divisibility SMALLINT NOT NULL,
  etching VARCHAR NOT NULL,
  -- Mint entry
  mint jsonb NULL,
  mints BIGINT NOT NULL,
  rnumber BIGINT NOT NULL,
  spacers INTEGER NOT NULL,
  supply BYTEA NOT NULL,
  symbol CHAR NULL,
  rtimestamp INTEGER NOT NULL
)
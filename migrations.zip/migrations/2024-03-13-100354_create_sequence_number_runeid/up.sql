-- Your SQL goes here
CREATE TABLE sequence_number_runeid (
    id BIGSERIAL PRIMARY KEY,
    sequence INTEGER NOT NULL,
    tx_height INTEGER NOT NULL,
    rune_index SMALLINT NOT NULL DEFAULT 0
)
-- This file should undo anything in `up.sql`
DROP TABLE sequence_number_runeid;
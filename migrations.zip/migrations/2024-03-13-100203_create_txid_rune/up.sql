-- Your SQL goes here
CREATE TABLE txid_rune (
  id BIGSERIAL PRIMARY KEY,
  tx_hash VARCHAR NOT NULL,
  tx_height INTEGER NOT NULL,
  rune_index SMALLINT NOT NULL DEFAULT 0
)